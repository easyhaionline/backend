// error , that's why commented
// {
    
//     "subject" : "chemistry",
//     "topic" : "organic",
//     "question" : "Question 1 Test 2",
//     "correctAnswer" : "Option C",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "chemistry",
//     "topic" : "physical",
//     "question" : "Question 2 Test 2",
//     "correctAnswer" : "Option B",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "chemistry",
//     "topic" : "organic",
//     "question" : "Question 3 Test 2",
//     "correctAnswer" : "Option D",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "maths",
//     "topic" : "line and angles",
//     "question" : "Question 4 Test 2",
//     "correctAnswer" : "Option D",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "maths",
//     "topic" : "trignometry",
//     "question" : "Question 5 Test 2",
//     "correctAnswer" : "Option B",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "physics",
//     "topic" : "electricity",
//     "question" : "Question 6 Test 2",
//     "correctAnswer" : "Option A",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "maths",
//     "topic" : "geometry",
//     "question" : "Question 7 Test 2",
//     "correctAnswer" : "Option D",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// },
// {
    
//     "subject" : "physics",
//     "topic" : "magnetism",
//     "question" : "Question 8 Test 2",
//     "correctAnswer" : "Option B",
//     "questionType" : "objective",
//     "options" : [ 
//         "Option A",
//         "Option B",
//         "Option C",
//         "Option D"
//     ],
//     "marks" : 1.0,
//     "number" : 4.0
// }


// //  creating test 



// "name" : "Test 2",
// "date" : "2022-04-05T18:29:53.056Z",
// "duration" : 90.0,
// "testType" : "Practice Test",
// "questions" : [ 
//     "62547d78f2ec187447e88f82"
//     "62547d78f2ec187447e88f83"
//     "62547d78f2ec187447e88f84"
//     "62547d78f2ec187447e88f85"
//     "62547d78f2ec187447e88f86"
//     "62547d78f2ec187447e88f87"
//     "62547d78f2ec187447e88f88"
//     "62547d78f2ec187447e88f89"
// ],
// "maxScore" : 100.0
// }


// testId -2 
// 62547f74f2ec187447e88f8a