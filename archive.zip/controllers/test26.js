const test = async (data) => {


    
    for(let i = 0; i < data.length; i++)
        console.log(data[i])

}

test(["abcd", "adafw", "eQFW"])